#include <iostream>

using namespace std;

int main()
{
    string str1="kert";
    string str2="ekes";
    int pos;
    cin>>pos;
    int karakt;
    cin>>karakt;
    str1.replace(pos,karakt,str2);
    cout<<str1;
    return 0;
}
