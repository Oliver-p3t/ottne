#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ifstream in("*Untitled3");
    int minz,minp;
    in>>minz;
    in>>minp;
    int daynr=1,S=0,dayp;
    int start=1;
    bool lehet=false;
    while(in>>dayp){
        if(dayp>minz){
            if(S==0){
            start=daynr;
            S=dayp;
        }
        else{
            S+=dayp;
        }
    }else{
    if(S>=minp&& daynr-start>1){
     cout<<start<<" "<<daynr-1<<" "<<S<<endl;
     lehet=true;
    }

    S=0;
    }
    daynr++;
    }
    if(S>minp && daynr-start>1){
        cout<<start<<" "<<daynr-1<<" "<<S<<endl;
     lehet=true;
    }

    if(!lehet){
        cout<<"nu exista";
    }

     in.close();
    return 0;

}
