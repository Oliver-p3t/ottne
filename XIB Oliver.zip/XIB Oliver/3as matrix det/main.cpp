#include <iostream>

using namespace std;

int main()
{
    int m[100][100];
    int n=3;
    int det;
    for(int sor=0;sor<n;sor++){
        for(int oszlop=0;oszlop<n;oszlop++){
            cin>>m[sor][oszlop];
        }
    }
   det = m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
        - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
        + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
    cout<<det;
    return 0;
}

