#include <iostream>
using namespace std;
int binaris(int szam[],int bal, int jobb,int ertek){
    if(bal>jobb){
        return -1;
    }
    int kozep=(bal+jobb)/2;
    if(tomb[kozep]==ertek){
        return kozep;
    }
    if(ertek<tomb[kozep]){
        return keres(tomb,bal,kozep-1,ertek)
    }else{
    return keres(tomb,kozep+1,jobb,ertek);
    }

}
int main()
{
    int szam[100];
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>szam[i];
    }
    cout<<binaris(szam,n)
    return 0;
}
