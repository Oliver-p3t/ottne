#include <iostream>
using namespace std;
void primek(int n,int& x, int&y){
x=0,y=0;
 for(int i=4;i<n;i++){
 bool prim=true;
 for(int oszto=2;oszto<i/2;oszto++){
    if(i%oszto==0){
        prim =false;
    }
 }
 if(prim){

    x=y;
    y=i;
 }
 }
}

int main()
{
    int n;
    cin>>n;
    int x,y;
    primek(n,x,y);
    cout<<x<<endl<<y;


    return 0;
}
