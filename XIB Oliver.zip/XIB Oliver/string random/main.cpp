#include <iostream>

using namespace std;

int main()
{
    string str1;
    cin>>str1;
    string str2;
    cin>>str2;
    size_t found;
    found=str1.find(str2);
    if(found!=string::npos){
        cout<<found;
    }else{
    cout<<"nincs benne kispajtas";
    }
    return 0;
}
