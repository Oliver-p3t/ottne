#include <iostream>
using namespace std;


int elem(int tomb[],int n,int i){
if(i==n-1){
    return tomb[i];
}
return tomb[i]+elem(tomb,n,i+1);
}


int main()
{
    int tomb[100];
    int n;
    n=5;
    for(int i=0;i<n;i++){
        cin>>tomb[i];
    }
    int i=0;
    cout<<elem(tomb,5,0);
    return 0;
}
