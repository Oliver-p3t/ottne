#include <iostream>

using namespace std;

int main()
{
    cout << "Hai Steaua!" << endl;
    return 0;
}
