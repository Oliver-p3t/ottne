#include <iostream>

using namespace std;

int main()
{
    cout <<"Forta Steaua!" << endl;
    return 0;
}
