#include <iostream>

using namespace std;

int main()
{
    int start[100]={14,15,16,13,17};
    int finish[100]={16,18,17,15,18};
    int activity[100]={1,2,3,4,5};
    int n=5;



    for(int i=1;i<n-1;i++){
        for(int j=i+1;j<n;j++){
                if(finish[i]>finish[j]){
                    swap(start[i],start[j]);
                    swap(finish[i],finish[j]);
                    swap(activity[i],activity[j]);

                }
        }
    }
    cout<<activity[1]<<" ";
    int jelen=0;
    for(int i=1;i<n;i++){
        if(start[i]>=finish[jelen]){
            jelen=i;
            cout<<activity[i]<<" ";
        }
    }




    return 0;
}
