#include <iostream>

using namespace std;

int main()
{
    string str1;
    string str2;
    getline(cin,str1);
    getline(cin,str2);
    str1.append(str2,0,str2.find(" "));
    cout<<str1;
    return 0;
}
