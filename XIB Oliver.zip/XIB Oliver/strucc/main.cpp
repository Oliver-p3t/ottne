#include <iostream>

using namespace std;

int main()
{
  struct diak{
  int azonosito;
  string nev;
  string osztaly;
  double media;
  };
  diak Krisikristof;
  Krisikristof.azonosito=01;
  Krisikristof.nev="Kristof";
  Krisikristof.osztaly="XI";
  Krisikristof.media=9,89;
  diak akibaki;
  akibaki.azonosito=02;
  akibaki.nev="Akos";
  akibaki.osztaly="XI";
  akibaki.media=8,67;
  diak suttyo;
  suttyo.azonosito=03;
  suttyo.nev="edvin";
  suttyo.osztaly="X";
  suttyo.media=9,11;

    int maxmedia,maxazonosito;
    int minmedia,minazonosito;
    maxmedia=Krisikristof.media;
    maxazonosito=Krisikristof.azonosito;
    if(akibaki.media>maxmedia){
        maxmedia=akibaki.media;
        maxazonosito=akibaki.azonosito;
    }
    if(suttyo.media>maxmedia){
        maxmedia=suttyo.media;
        maxazonosito=suttyo.azonosito;
    }
    cout<<maxazonosito<<" ";
    minmedia=Krisikristof.media;
    minazonosito=Krisikristof.azonosito;
    if(akibaki.media<minmedia){
        minmedia=akibaki.media;
        minazonosito=akibaki.azonosito;
    }
    if(suttyo.media<minmedia){
        minmedia=suttyo.media;
        minazonosito=suttyo.azonosito;
    }
    cout<<minazonosito;

    return 0;
}
