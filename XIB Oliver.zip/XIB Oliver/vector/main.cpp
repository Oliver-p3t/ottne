#include <iostream>
#include <vector>
using namespace std;

int main()
{
    vector<int>szamok;
    szamok.push_back(1);
    szamok.push_back(2);
    szamok.push_back(3);
    szamok.push_back(4);
    szamok.push_back(5);
    for(int i=0;i<szamok.size();i++){
        cout<<szamok[i]<<" ";
    }
    cout<<endl;
    szamok.pop_back();
    for(int i:szamok){
        cout<<i<<" ";
    }
    return 0;
}
