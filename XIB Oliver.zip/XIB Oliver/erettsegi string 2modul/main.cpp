#include <iostream>

using namespace std;

int main()
{
    int n;
    cin>>n;
    int temp=n,ujszam=0,hatvany=1,szj;
    while(temp>0){
        szj=temp%10;
        temp/=10;
        if(szj==5 && temp%10==2){
            szj=6;
        }

        ujszam=ujszam+hatvany*szj;
        hatvany*=10;
    }
    cout<<ujszam;
    return 0;
}
