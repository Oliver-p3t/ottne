#include <iostream>

using namespace std;

int main()
{
    int n,k;
    cin>>n;
    cin>>k;
    int p=k;
    for(int i=0;i<p;i++){
            if(n>0){
        cout<<n*k<<" ";
        n-=1;}else{
        break;}
    }
    return 0;
}
