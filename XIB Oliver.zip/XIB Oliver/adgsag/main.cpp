#include <iostream>

using namespace std;

int main()
{
    int n,i;
    cin>>n;
    for(i=1;i<=2*n-1;i++)
    cout<<'*';
    cout<<endl;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=i;j++)cout<<"#";
        for(j=1;j<=)
    }
}
