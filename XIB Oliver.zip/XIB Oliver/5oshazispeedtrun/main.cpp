#include <iostream>

using namespace std;

int main()
{
    string str1;
    cin>>str1;
    size_t found;
    char v[5]={'a','u','o','i','e'};
    for(int i=0;i<5;i++){
    found=str1.find(v[i]);
         while(found!=string::npos){
                str1.replace(found,1,"mpZm");
             found=str1.find(v[i],found+3);
         }
    }
    cout<<str1;
    return 0;
}

