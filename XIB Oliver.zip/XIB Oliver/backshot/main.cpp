#include <iostream>

using namespace std;
 const int n=3;
 short xlepes[]={-1,0,1,0};
 short ylepes[]={0,1,0,-1};
bool lehet(char lab[n][n],int x, int y){
if(lab[x][y]=='F'){
    return false;
}
if(lab[x][y]=='E')
    return false;

if(x<0||x>n-1)
    return false;

if(y<0||y>n-1)
    return false;

return true;
}
void print(char lab[][n]){
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            cout<<lab[i][j]<< " " ;
            cout<<endl;
        }
    }
}
void backtrack(char lab[][n],int x,int y){
    if(x==n-1&&y==n-1){
    print(lab);
    return;
    }
    for(int i=0;i<4;i++){
       if(lehet(lab,x+xlepes[i],y+ylepes[i])){
            int newx=x+xlepes[i];
            int newy=y+ylepes[i];
            char templab[n][n];
            for(int sor=0;sor<n;sor++){
               for(int oszlop=0;oszlop<n;oszlop++){
                templab[sor][oszlop]=lab[sor][oszlop];
                templab[newx][newy]='E';
                backtrack(templab,newx,newy);
               }
            }
        }
    }
}
int main()
{
    char lab[3][3]={{'E','-','-'},
                    {'F','F','-'},
                    {'-','-','-'}
                    };
    backtrack(lab,0,0);
    return 0;
}
