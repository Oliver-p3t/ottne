#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ifstream file("bac.in");
    int jelzok[100];
    int n=0;
    while(file>>jelzok[n]){
        n++;
    }
    int akthossz=0,maxhossz=0,aktkezdo=0,maxkezdo=0;
    for(int i=0;i<n;i++){
        if(jelzok[i]==jelzok[i+1]-1){
            akthossz++;
        }
            if(akthossz>=2&&akthossz>maxhossz){
                maxhossz=akthossz;
                maxkezdo=aktkezdo;
            }

            akthossz=1;
            aktkezdo=i;
    }
    if(maxhossz>=2){
        for(int i=maxkezdo;i<maxkezdo+maxhossz;i++) {
            cout<<jelzok[i]<< " ";
        }
    } else {
        cout<<"nu exista";
    }
    return 0;
}
