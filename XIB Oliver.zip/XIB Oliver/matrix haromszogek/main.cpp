#include <iostream>
#include <stdlib.h>
using namespace std;

int main()
{
    int m[100][100];
    int foatlo_osszeg=0;
    int mellekatlo_osszeg=0;
    int sorok_szama;
    cin>>sorok_szama;
    int oszlop_szama;
    oszlop_szama=sorok_szama;
    int n=sorok_szama;
    for(int sor=0;sor<sorok_szama;sor++){
        for(int oszlop=0;oszlop<oszlop_szama;oszlop++){
            cout<<"m["<<sor<<"]["<<oszlop<<"] ";
            m[sor][oszlop]=rand()%10;
        }
    }
    for(int sor=0;sor<sorok_szama;sor++){
        for(int oszlop=0;oszlop<oszlop_szama;oszlop++){
                if(sor==oszlop){
                    foatlo_osszeg+=m[sor][oszlop];
                }
                if(sor+oszlop==n-1){
                    mellekatlo_osszeg+=m[sor][oszlop];
                }
        }
        }
        cout<<endl<<foatlo_osszeg<<" "<<endl<<mellekatlo_osszeg;
    return 0;
}
