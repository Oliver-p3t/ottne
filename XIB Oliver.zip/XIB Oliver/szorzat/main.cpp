#include <iostream>

using namespace std;

int main()
{
    int a, b, c, d;
    cout<<"a= ";
    cin>>a;
    cout<<"b= ";
    cin>>b;
    cout<<"c= ";
    cin>>c;
    cout<<"d= ";
    cin>>d;
    cout<<"A negy szam szorzata"<<a*b*c*d;
    return 0;
}
