#include <iostream>

using namespace std;
void cuburi(int n){

for(n;n>0;n--){

    cout<<n*n*n<<" ";
}
}
int main()
{
    int n;
    cin>>n;
    cuburi(n);
    return 0;
}
