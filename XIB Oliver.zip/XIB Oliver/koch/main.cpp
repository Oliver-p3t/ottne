#include <iostream>
#include <cmath>
#include <graphics.h>
using namespace std;
struct point{
int x,y;
};
point step(point p,double szog,double len){
return{p.x+len*cos(szog),p.y+len*sin(szog)};
}
void koch(point start,double szog,double len, int k){
if(k==0){
    point end=step(start,szog,len);
    line(start.x,start.y,end.x,end.y);
}else{
    double harmad=len/3.0;
    koch(start,szog,harmad,k-1);
    point p2=step(start,szog,harmad);
    point p2=step(start,szog,harmad);
    koch(p2,szog-M_PI/3.0,harmad,k-1);
    point p3=step(p2,szog-M_PI/3.0,harmad);
    koch(p3,szog+M_PI/3.0,harmad,k-1);
    point p4=step(p3,szog+M_PI/3.0,harmad);
    koch(p4,szog,harmad,k-1);
}
}
int main()
{
    int k;
    cin>>k;
    const int w=1500;
    const int h=600;
    initwindow(w,h,"koch");
    setcolor(CYAN);
    point start = {50,h-50};
    koch(start,0,w-50,k);
    getch();
    closegraph();
    return 0;
}
