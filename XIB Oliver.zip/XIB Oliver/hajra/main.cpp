#include <iostream>

using namespace std;

int main()
{
    string str1="alfa";
    string str2="ma";
    str1.insert(2,str2);
    cout<<str1;
    return 0;
}
