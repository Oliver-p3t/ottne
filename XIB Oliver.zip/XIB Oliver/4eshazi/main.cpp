#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    int n;
    ifstream in("input.txt");
    ofstream out("lnko.out");
    in>>n;
    int m[100][100];
    int keleti=0;
    int nyugati=0;
    for(int sor=0;sor<n;sor++){
        for(int oszlop=0;oszlop<n;oszlop++){
            in>>m[sor][oszlop];
        }
    }
    for(int sor=0;sor<n;sor++){
        for(int oszlop=0;oszlop<n;oszlop++){
            if(sor<oszlop && sor+oszlop>n-1){
                keleti+=m[sor][oszlop];
            }
            if(sor>oszlop && sor+oszlop<n-1){
                nyugati+=m[sor][oszlop];
            }
        }
    }
    while(keleti!=nyugati){
        if(keleti>nyugati){
            keleti-=nyugati;
        }else{
        nyugati-=keleti;
        }
    }
    out<<nyugati;
    in.close();
    out.close();
    return 0;
}
