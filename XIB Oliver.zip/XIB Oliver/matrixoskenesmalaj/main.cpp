#include <iostream>

using namespace std;

int main()
{
    int m[100][100];
    int n=2;
    int det=0;
    int foatlo=1;
    int mellekatlo=1;
    for(int sor=0;sor<n;sor++){
        for(int oszlop=0;oszlop<n;oszlop++){
            cin>>m[sor][oszlop];
        }
    }
    for(int sor=0;sor<2;sor++){
        for(int oszlop=0;oszlop<n;oszlop++){
            if(sor==oszlop){
                foatlo*=m[sor][oszlop];
            }
             if(sor+oszlop==n-1){
                mellekatlo*=m[sor][oszlop];
            }
        }
    }
    det=foatlo-mellekatlo;
    cout<<det;
    return 0;
}
