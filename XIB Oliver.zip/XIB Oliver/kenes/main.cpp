#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ifstream file("bac.in");
    int sorszam=0, dbszam=0;
    int joidol,joidov,esetidokezdet,esetidovege;
    file>>joidok;
    file>>joidov;
    int k=1;
    while(file>>esetidokezdet>>esetidovege){
        if(esetidokezdet<joidov && (esetidovege-joidok)>=1){
            dbszam++;
            sorszam=k;

        }
        k++;
    }
    cout<<dbszam<<endl<<sorszam;
    file.close();
    return 0;
}
