#include <iostream>

using namespace std;

int main()
{
    int a, b, c, d, e, ma;
    cout<<"Add meg az a szamot";
    cin>>a;
    cout<<"Add meg a b szamot";
    cin>>b;
    cout<<"Add meg a c szamot";
    cin>>c;
    cout<<"Add meg a d szamot";
    cin>>d;
    cout<<"Add meg az e szamot";
    cin>>e;
    ma=(a+b+c+d+e)/5;
    cout<<"A szamtani arany="<<ma;
    return 0;
}
