#include <iostream>

using namespace std;

int main()
{
    int a, b, c, s=0;
    cout<<"a= ";
    cin>>a;
    cout<<"b= ";
    cin>>b;
    cout<<"c= ";
    cin>>c;
    s=a+b+c;
    cout<<"Az osszeg="<<s;
    return 0;
}
