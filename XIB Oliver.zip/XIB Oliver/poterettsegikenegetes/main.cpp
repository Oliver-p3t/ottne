#include <iostream>

using namespace std;

int main()
{
    int x,y;
    cin>>x;
    cin>>y;
    int terulet;
    terulet=x*y;
    int oszto;
    for(oszto=2;oszto<terulet/2;oszto+=2){
        int reszek=terulet/oszto;
        if(oszto<reszek && terulet%oszto==0){
        cout<<oszto<<" parcele de arie "<<reszek<<endl;
        }

    }

    return 0;
}
