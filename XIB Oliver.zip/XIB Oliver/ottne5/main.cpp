#include <iostream>

using namespace std;

int main()
{
  int n,s=0;
  cin>>n;
  for(int oszto=4;oszto<=n;oszto++){
    if(n%oszto==0){
        bool prim=true;
        for(int poszto=2;poszto<=oszto/2;poszto++){
            if(oszto%poszto==0){
                prim=false;
            }
        }
        if(!prim){
            s+=oszto;
        }
    }
  }
  cout<<s;
    return 0;
}
