#include <iostream>

using namespace std;

int main()
{
    int n;
    cin>>n;
    int m[100][100];
    for(int sor=0;sor<n;sor++){
        for(int oszlop=0;oszlop<n;oszlop++){
            cin>>m[sor][oszlop];

        }

    }
    for(int sor=0;sor<n;sor++){
        for(int oszlop=0;oszlop<n;oszlop++){

            if(sor+oszlop==n-1){

                m[sor][oszlop]=m[sor][oszlop+1];

            }

        }
    }
    for(int sor=0;sor<n;sor++){
        m[sor][n-1]=0;
    }
    for(int sor=0;sor<n;sor++){
        for(int oszlop=0;oszlop<n-1;oszlop++){
            cout<<m[sor][oszlop]<<" ";
        }
        cout<<endl;
    }
    return 0;
}
