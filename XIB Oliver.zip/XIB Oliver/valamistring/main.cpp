#include <iostream>

using namespace std;

int main()
{
    string str1;
    getline(cin,str1);
    int nr=1;
    size_t found;
    found=str1.find(" ");
    while(found!=string::npos){
        found=str1.find(" ",found+1);
        nr++;

    }
    cout<<nr;
    return 0;
}
