#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ifstream in("input.txt");
    ofstream out("output.txt");
    int a[100][100];
    int m,n;
    in>>n>>m;
    for(int sor=0;sor<n;sor++){
        for(int oszlop=0;oszlop<m;oszlop++){
            in>>a[sor][oszlop];
        }
    }
    for(int sor=0;sor<n;sor++){
        for(int oszlop=0;oszlop<m;oszlop++){
                int temp=a[sor][oszlop];
                int pallindrom=0;
                bool lehet=false;
                int szj=0;
             while(temp>0){
                szj=temp%10;
                temp/=10;
                pallindrom=pallindrom*10+szj;
             }
             if(pallindrom==a[sor][oszlop]){
                lehet=true;
             }
            if(lehet){
                out<<"1 ";
            }else{
            out<<"0 ";}
        }
      out<<endl;
    }

    in.close();
    out.close();
    return 0;
}
