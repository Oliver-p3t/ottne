#include <iostream>
int hatvany(int x,int htvny){
    if(htvny==0){
        return 1;
    }else{
    return x*hatvany(x,htvny-1);}

}
using namespace std;

int main()
{
    int x;
    cin>>x;
    int htvny;
    cin>>htvny;
    cout<<hatvany(x,htvny);
    return 0;
}
