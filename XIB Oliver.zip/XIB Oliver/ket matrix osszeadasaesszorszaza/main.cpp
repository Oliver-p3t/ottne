#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ifstream in("input.txt");
    int a[100][100];
    int b[100][100];
    int n;
    in>>n;
    for(int sor=0;sor<n;sor++){
        for(int oszlop=0;oszlop<n;oszlop++){
            in>>a[sor][oszlop];
        }
    }
    for(int sor=0;sor<n;sor++){
        for(int oszlop=0;oszlop<n;oszlop++){
            in>>b[sor][oszlop];
        }
    }
    cout<<"osszeadas: "<<endl;
    for(int sor=0;sor<n;sor++){
        for(int oszlop=0;oszlop<n;oszlop++){
            cout<<a[sor][oszlop]+b[sor][oszlop]<<" ";
        }
        cout<<endl;
    }
    cout<<"szorzas: "<<endl;
    for(int sor=0;sor<n;sor++){
        for(int oszlop=0;oszlop<n;oszlop++){
            cout<<a[sor][oszlop]*b[sor][oszlop]+
            a[sor][oszlop+1]*b[sor+1][oszlop]+
            a[sor][oszlop+2]*b[sor+1][oszlop]
            <<" ";
        }
        cout<<endl;
    }
    in.close();
    return 0;
}
