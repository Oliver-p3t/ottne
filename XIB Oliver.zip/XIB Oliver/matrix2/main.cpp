#include <iostream>
#include <stdlib.h>
using namespace std;

int main()
{
    int a[100][100],n,m;
    cin>>n>>m;

    for(int sor=0;sor<n;sor++){
        for(int oszlop=0;oszlop<m;oszlop++){

            a[sor][oszlop]=rand()%10;
        }
    }
    for(int sor=0;sor<n;sor++){
        for(int oszlop=0;oszlop<m;oszlop++){
        if(sor==oszlop){
            a[sor][oszlop]=0;
        }
        if(sor>oszlop){
           a[sor][oszlop]=-a[sor][oszlop];
           }
        }
        }

    for(int sor=0;sor<n;sor++){
        for(int oszlop=0;oszlop<m;oszlop++){
           cout<<a[sor][oszlop]<<" ";}
           cout<<endl;
    }

    return 0;
}
