#include <iostream>

using namespace std;

int main()
{
    string str1="alfa";
    string str2="ma";
    int pos=2;
    str1.insert(pos,str2);
    cout<<str1;
    return 0;
}
