#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ifstream in("input.txt");
    ofstream out("output.txt");
    int a[100][100];
    int m,n;
    in>>n>>m;
    for(int sor=0;sor<n;sor++){
        for(int oszlop=0;oszlop<m;oszlop++){
            in>>a[sor][oszlop];
        }
    }
    for(int sor=0;sor<n;sor++){
        for(int oszlop=0;oszlop<m;oszlop++){
                int prim=false;
            for(int oszto=1;oszto<=a[sor][oszlop]/2;oszto++){
                if(a[sor][oszlop]%oszto==0){
                    prim=false;
                }else{
                prim=true;}
            }
            if(prim || a[sor][oszlop]<4){
                out<<"1 ";
            }else{
            out<<"0 ";}
        }
      out<<endl;
    }

    in.close();
    out.close();
    return 0;
}
