#include <iostream>
#include <fstream>
using namespace std;
int n,m,i,j,x,y,a[100][100],mx=-999;
int main()
{
    ifstream f("adiacenta1.in");
    ofstream g("adiacenta1.out");
    while(f>>x>>y)
    {
        if(x>mx)mx=x;
        if (y>mx) mx=y;
        a[x][y]=1;
        a[y][x]=1;
    }
    n=mx;
    for (i=1; i<=mx; i++)
    {
        for (j=1; j<=n; j++)
            g<<a[i][j]<<" ";
        g<<endl;
    }
}
