#include <iostream>
using namespace std;

int main()
{
    int x, y = 0;
    cin >> x;
    while (x != 0) {
        if (x > 9) {
            while (x > 9) {
                x = x / 10;
            }
        }
        y = y * 10 + x;
        cin >> x;
    }
    cout << y << endl;
    return 0;
}
