#include <iostream>

using namespace std;
 int kisebb(int a, int b){
 if(a<b){
    return a;
 }
 return b;}

 int min(int jobbindex,int balindex,int a[]){
 if(jobbindex==balindex){
    return a[jobbindex];
 }
 if(balindex+1==jobbindex){
    return kisebb(a[balindex],a[jobbindex]);

 }
 int kozep=(balindex+jobbindex)/2;
 return kisebb(min(balindex,kozep,a),min(kozep+1,jobbindex,a));
 }
int main()
{
    int a[5]={1,2,3,4,-1};
    cout<<min(0,5,a);
    return 0;
}
