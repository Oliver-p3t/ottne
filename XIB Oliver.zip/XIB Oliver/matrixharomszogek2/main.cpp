#include <iostream>
#include <stdlib.h>
using namespace std;

int main()
{
    int m[100][100];
    int kelet_osszeg=0;
    int eszak_osszeg=0;
    int del_osszeg=0;
    int nyugat_osszeg=0;
    int sorok_szama;
    cin>>sorok_szama;
    int oszlop_szama;
    oszlop_szama=sorok_szama;
    int n=sorok_szama;
    for(int sor=0;sor<sorok_szama;sor++){
        for(int oszlop=0;oszlop<oszlop_szama;oszlop++){

            m[sor][oszlop]=rand()%10;
        }
    }
     for(int sor=0;sor<sorok_szama;sor++){
        for(int oszlop=0;oszlop<oszlop_szama;oszlop++){
            cout<<m[sor][oszlop]<<" ";
        }
        cout<<endl;
    }
    for(int sor=0;sor<sorok_szama;sor++){
        for(int oszlop=0;oszlop<oszlop_szama;oszlop++){
            if(sor<oszlop && sor+oszlop<n-1){
                eszak_osszeg+=m[sor][oszlop];
            }
            if(sor<oszlop && sor+oszlop>n-1){
                kelet_osszeg+=m[sor][oszlop];
            }
             if(sor>oszlop && sor+oszlop>n-1){
                del_osszeg+=m[sor][oszlop];
            }
             if(sor>oszlop && sor+oszlop<n-1){
                nyugat_osszeg+=m[sor][oszlop];
            }
        }
        }
        cout<<endl<<eszak_osszeg<<" "<<endl<<kelet_osszeg<<endl<<del_osszeg<<endl<<nyugat_osszeg;
    return 0;
}
