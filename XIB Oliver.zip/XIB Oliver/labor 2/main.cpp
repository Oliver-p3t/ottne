#include <iostream>

using namespace std;

int main()
{
    int n,x,y,S=0;
    cin>>n;
    int hszj;
    hszj=n%10;
    cin>>x;
    cin>>y;
    for(int i=x;i<=y;i++){
        int aux=i;
        bool nagyobb=true;
        while(aux>0){
            int szj=aux%10;
            if(szj<hszj){
                nagyobb=false;
            }
            aux=aux/10;
        }
        if(nagyobb){
            S+=i;
        }
    }
    cout<<S;
    return 0;
}
