#include <iostream>

using namespace std;

int main()
{
    int m[100][100];
    int n;
    cin>>n;
    int k=1;
    int max=0;
    for(int sor=0;sor<n;sor++){
        for(int oszlop=0;oszlop<n;oszlop++){
            cin>>m[sor][oszlop];
        }
        cout<<endl;
    }
    for(int sor=0;sor<n-1;sor++){
        for(int oszlop=0;oszlop<n-1;oszlop++){
            while(m[sor][oszlop]==m[sor+1][oszlop+1]&&m[sor+1][oszlop]==m[sor][oszlop]&& m[sor][oszlop]==m[sor][oszlop+1]
                  &&sor<n-1&&oszlop<n-1){
              k++;
              sor++;
              oszlop++;
            }
            if(max<k){
                max=k;
            }
            k=1;
        }
    }
    cout<<k;
    return 0;
}
