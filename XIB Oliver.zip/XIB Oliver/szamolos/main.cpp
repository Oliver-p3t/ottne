#include <iostream>

using namespace std;

int main()
{
   int a, b, c, E;
   cout<<"a= ";
   cin>> a;
   cout<<"b= ";
   cin>>b;
   cout<<"c= ";
   cin>> c;
   E=a-b+c;
   cout<<"Az eredmeny="<<E;
    return 0;
}
