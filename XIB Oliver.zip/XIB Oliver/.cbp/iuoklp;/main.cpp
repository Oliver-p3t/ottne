#include <iostream>

using namespace std;
int i,n;
int main()
{   cin>>n;
    for(i=1;i<=n;i++)
      if(1%2==0) cout<<2*i<<" ";
}
