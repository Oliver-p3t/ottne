#include <iostream>

using namespace std;

int main()
{
    int x,y;
    int nr;
    cin>>x>>y;
    int max=x;
    if(max<y){
        max=y;
    }
    for(int oszto=2;oszto<=max;oszto++){
        int nrx=0;

        int nry=0;
    while(x%oszto==0){
        nrx++;
        x/=oszto;
    }
     while(y%oszto==0){
        nry++;
        y/=oszto;
    }
    if(nrx>0 && nrx==nry){
        nr++;
    }
    cout nr;
    return 0;
}
