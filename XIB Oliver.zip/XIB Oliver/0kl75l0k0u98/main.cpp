#include <iostream>

using namespace std;
long long s,n;
int main()
{   cin >>n;
    a=n/1000;
    b=n/100%10;
    c=n/10%10;
    d=n%10;
    nr1=a*10+b;
    nr2=b*10+a;
    if(nr1>nr2) mx1=nr1;
    else mx=nr2;
    nr3=b*10+c;
    nr4=c*10+b;
    if(nr3>nr4) mx2=nr3;
    else mx=nr4;

    cout<<;
}  return 0;
