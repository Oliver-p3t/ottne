#include <iostream>

using namespace std;

int main()
{
    int szam1, szam2, szam3, P=1;
    cout<<"elso szam";
    cin>>szam1;
    cout<<"masodik szam";
    cin>>szam2;
    cout<<"harmadik szam";
    cin>>szam3;
    if(szam1%2==0)
    {
        P=P*szam1;
    }
    if(szam2%2==0)
    {
        P=P*szam2;
    }
    if(szam3%2==0)
    {
        P=P*szam2;
    }
    cout<<P;
    return 0;
}
