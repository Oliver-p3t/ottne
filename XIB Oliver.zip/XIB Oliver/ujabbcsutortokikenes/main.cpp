#include <iostream>

using namespace std;

int main()
{
   int k,n;
   cin>>k;
   int proba=k;
   int osztokossz=0;
   bool lehet=false;
   while(!lehet){
   while(proba>0){
        osztokossz+=proba%10;
        proba/=10;
   }
   if(k%osztokossz==0){
    n=k;
    cout<<n<<" harsad szam";
    lehet=true;
   }else{
    k-=1;
    proba=k;
    osztokossz=0;
   }
   }
    return 0;
}
