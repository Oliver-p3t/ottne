#include <iostream>

using namespace std;

int main()
{
    string nev;
    cin>>nev;
    cout<<"Hello "<<nev;
    return 0;
}
