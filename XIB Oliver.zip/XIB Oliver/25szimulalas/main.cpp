#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    int nc,np;
    ifstream file("bijuterii.in");
    file>>nc;
    file>>np;
    bool lehet=false;
    int fulbev[100],nyakl[100];
    for(int i=0;i<nc;i++){
        file>>fulbev[i];
        if(fulbev[i]>99){
            fulbev[i]/=10;
        }
    }
    for(int i=0;i<np;i++){
        file>>nyakl[i];
        if(nyakl[i]>99){
            nyakl[i]/=10;
        }
    }
    for(int i=0;i<nc;i++){
        for(int j=0;j<np;j++){
            if(fulbev[i]==nyakl[j]){
                lehet=true;
            }
            int tukor=nyakl[j]/10*10+nyakl[j]%10\
            if(tukor==fulbev[i]){
                lehet=true;
            }
        }

    }
    if(lehet){
        cout<<"DA";
    }
    if(!lehet){
        cout<<"NU";
    }
    file.close();
    return 0;
}
