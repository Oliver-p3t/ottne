#include <iostream>

using namespace std;

int main()
{
    string str1;
    cin>>str1;
    string str2;
    cin>>str2;
    char maganhangzo[6]={'a', 'e', 'i', 'o', 'u'};
    int hossz1=str1.length();
    int hossz2=str2.length();
    int mag1=0;
    int mag2=0;
    for(int i=0;i<hossz1;i++){
        for(int j=0;j<6;j++){
        if(str1[i]==maganhangzo[j]){
            mag1++;
        }
    }}
   for(int i=0;i<hossz2;i++){
        for(int j=0;j<6;j++){
        if(str2[i]==maganhangzo[j]){
            mag2++;
        }
    }}
    if(mag1==mag2){
        cout<<"IGEN";
    }else{
        cout<<"NEM";
    }
    return 0;
}
