#include <iostream>

using namespace std;

int main()
{
    int a, b, c, d, e, f, p=0, r=0;
    cin>>a>>b>>c>>d>>e>>f;
    if(a%2==0)
    {
        p=p+a;
    }
    else
    {
        r=r+a;
    }
    if(b%==0)
    {
        p=p+b;
    }
    else
    {
        r=r+b;
    }
    if(c%2==0)
    {
        p=p+c;
    }
    else
    {
        r=r+c;
    }
    if(d%2==0)
    {
        p=p+d;
    }
    if(e%2==0)
    {
        p=p+e;
    }
    else
    {
        r=r+e;
    }
    if(f%2==0)
    {
        p=p+f;
    }
    else
    {
        r=r+f;
    }
    cout<<"parosok osszege"<<p;
    cout>>"paratlanok osszege"<<r;
    return 0;
}
