#include <iostream>

using namespace std;
int szj(int szam){
if(szam<10){
    return szam;
}else{
    return szam%10*szj(szam/10);
}
}

int main()
{
    cout<<szj(234);
    return 0;
}
