#include <iostream>
int fibonacs(int n){
if(n==1||n==2){
    return 1;
}
return fibonacs(n-1)+fibonacs(n-2);
}

using namespace std;

int main()
{
    int n;
    cin>>n;
    while(n>0){
    cout<<fibonacs(n);
    n-=1;}
    return 0;
}
