#include <iostream>
long paratlan(long n);
int paros(long n){
if(n==2){return 2;}
if(n%2==0){
    return n+paros(n-1);
}}
long paratlan(long n){
    if(n==1){
        return 1;
    }
    return n+paros(n-1);
}


using namespace std;

int main()
{
    long n;
    cin>>n;
    if(n%2==0){
    cout<<paros(n);}else{
        cout<<paratlan(n);
    }
    return 0;
}
