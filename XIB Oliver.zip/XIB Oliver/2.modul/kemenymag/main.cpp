#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ifstream in("input.txt");
    ofstream out("output.txt");
    int n;
    in>>n;
    string s1[100][100];
    int shift='A'-'a';
    for(int sor=0;sor<n;sor++){
        for(int oszlop=0;oszlop<n;oszlop++){
            in>>s1[sor][oszlop];
        }
    }
    for(int sor=0;sor<n;sor++){
        for(int oszlop=0;oszlop<n;oszlop++){
            if(sor<oszlop){
                for(int i=0;i<2;i++){
            s1[sor][oszlop][i]+=shift;}
             if(sor<oszlop){
                for(int i=s1[sor][oszlop].length();i>s1[sor][oszlop].length()-2;i--){
            s1[sor][oszlop][i]+=shift;}

    }}}}
    for(int sor=0;sor<n;sor++){
        for(int oszlop=0;oszlop<n;oszlop++){
            out<<s1[sor][oszlop];
        }
        cout<<endl;
    }


    return 0;
}
