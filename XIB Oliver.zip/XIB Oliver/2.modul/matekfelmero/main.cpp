#include <iostream>

using namespace std;
int tukor(int szam, int ujszam){
if(szam==0){
    return ujszam;
}
return tukor(szam/10,ujszam*10+szam%10);
}
int lnko(int x, int y){
if(x==y){
    return x;
}
if(x>y){
    return lnko(x-y,y);
}else{
    return lnko(x,y-x);
}
}
int main()
{
    cout<<tukor(1555,0)<<endl;
    cout<<lnko(4,6);
    return 0;
}
