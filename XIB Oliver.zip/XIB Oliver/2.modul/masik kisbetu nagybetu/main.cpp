#include <iostream>

using namespace std;

int main()
{
   string s1;
   cin>>s1;
   string s2;
   cin>>s2;
   int shift='A'-'a';
   if(s2=="kis"){
    for(int i=0;i<s1.size();i++){
       if(s1[i]<'Z'&&s1[i]>='A'){
            s1[i]-=shift;
    }}
   }
   if(s2=="nagy"){
    for(int i=0;i<s1.size();i++){
            if(s1[i]=<'z'&&s1[i]>='a'){
               s1[i]+=shift;
            }

    }
   }

   cout<<s1;
    return 0;
}
