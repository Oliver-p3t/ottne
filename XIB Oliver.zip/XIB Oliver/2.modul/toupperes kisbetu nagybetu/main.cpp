#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
   string s1;
   getline(cin,s1);
   string s2;
   cin>>s2;
   string s2nagy=s2;
   transform(s2nagy.begin(),s2nagy.end(),s2nagy.begin(), ::toupper);
    size_t found=s1.find(s2);
    while(found!=string::npos){
        s1.replace(found,s2.length(),s2nagy);
        found=s1.find(s2,found+1);

    }
    cout<<s1;

    return 0;
}
