#include <iostream>

using namespace std;
bool isPrim(int oszto){
bool prim=true;
for(int i=2;i<oszto/2+1;i++){
    if(oszto%i==0){
        return false;
    }
}
return true;

}

bool isPallindrom(int szam){
int ujszam=0,szj,temp=szam;
while(szam>0){
szj=szam%10;
szam/=10;
ujszam=ujszam*10+szj;
if(ujszam==temp){
    return true;
}
}
return false;
}
int lnko(int a, int b){
while(a!=b){
    if(a>b){
        a=a-b;
    }else{
    b=b-a;}
}

return 0;}
int main()
{
cout<<"Mit szeretnel csinalni?"<<endl;
cout<<"Megvizsgalni, hogy egy szam prim-e"<<endl<<"Megvizsgalni, hogy egy szam pallindrom-e"<<endl<<"Megkeresni ket szam legnagyobb kozos osztojat";


    return 0;
}
